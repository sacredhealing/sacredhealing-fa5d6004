
export enum MeditationStyle {
  INDIAN_VEDIC = 'Indian (Vedic)',
  SHAMANIC = 'Shamanic',
  MYSTIC = 'Mystic',
  TIBETAN = 'Tibetan',
  SUFI = 'Sufi',
  ZEN = 'Zen (Japanese)',
  NATURE_HEALING = 'Nature Healing',
  OCEAN_WATER = 'Ocean / Water',
  SOUND_BATH = 'Sound Bath',
  CHAKRA_BALANCING = 'Chakra Balancing',
  HIGHER_CONSCIOUSNESS = 'Higher Consciousness',
  RELAXING = 'Relaxing',
  FOREST = 'Forest',
  BREATH_FOCUS = 'Breath Focus',
  KUNDALINI = 'Kundalini Energy',
  CUSTOM_CLOUD = 'Custom Cloud Asset',
  LOCAL_ASSET = 'Local WAV/MP3 Loop'
}

export enum StemType {
  FULL_MIX = 'Full Mix',
  VOCAL_FOCUS = 'Vocal Focus',
  AMBIENT_FOCUS = 'Ambient Focus',
  INSTRUMENTAL = 'Instrumental'
}

export interface AudioFile {
  name: string;
  size: number;
  type: string;
  url: string;
  sourceType?: 'local' | 'youtube';
}

export interface BinauralConfig {
  enabled: boolean;
  targetFrequency: number;
  carrierFrequency: number;
}

export interface HealingFrequency {
  name: string;
  freq: number;
  description: string;
}

export const HEALING_FREQUENCIES: HealingFrequency[] = [
  { name: '174 Hz', freq: 174, description: 'Foundation / Pain Relief' },
  { name: '285 Hz', freq: 285, description: 'Quantum Cognition' },
  { name: '396 Hz', freq: 396, description: 'Liberating Guilt & Fear' },
  { name: '417 Hz', freq: 417, description: 'Undoing Situations' },
  { name: '432 Hz', freq: 432, description: 'Natural Harmony' },
  { name: '528 Hz', freq: 528, description: 'Transformation / DNA Repair' },
  { name: '639 Hz', freq: 639, description: 'Connecting Relationships' },
  { name: '741 Hz', freq: 741, description: 'Expression / Solutions' },
  { name: '852 Hz', freq: 852, description: 'Returning to Spiritual Order' },
  { name: '963 Hz', freq: 963, description: 'Divine Consciousness' }
];
