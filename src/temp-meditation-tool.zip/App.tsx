
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  MeditationStyle, 
  AudioFile, 
  BinauralConfig, 
  HEALING_FREQUENCIES,
  StemType
} from './types';
import StyleGrid from './components/StyleGrid';
import PlayerControls from './components/PlayerControls';
import FileUploader from './components/FileUploader';
import AudioEngine from './components/AudioEngine';
import Visualizer from './components/Visualizer';
import ProcessingTerminal from './components/ProcessingTerminal';

const App: React.FC = () => {
  const [activeStyle, setActiveStyle] = useState<MeditationStyle>(MeditationStyle.INDIAN_VEDIC);
  const [files, setFiles] = useState<AudioFile[]>([]);
  const [healingFreq, setHealingFreq] = useState<number>(432);
  const [binaural, setBinaural] = useState<BinauralConfig>({
    enabled: true,
    targetFrequency: 10,
    carrierFrequency: 200
  });
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [ytUrl, setYtUrl] = useState('');
  const [ytStatus, setYtStatus] = useState<'idle' | 'linking' | 'ready'>('idle');
  const [ytProgress, setYtProgress] = useState(0);
  
  const [volumes, setVolumes] = useState({ ambient: 50, binaural: 40, healing: 20, user: 80 });
  const [fx, setFx] = useState({ reverb: 20, delay: 10, delayTime: 400, warmth: 30 });
  const [stemMode, setStemMode] = useState<StemType>(StemType.FULL_MIX);
  
  const [status, setStatus] = useState<{ type: 'error' | 'info' | 'success', msg: string } | null>(null);
  const [spectralInsight, setSpectralInsight] = useState<string>('');

  const engineRef = useRef<AudioEngine | null>(null);

  useEffect(() => {
    if (status) {
      const timer = setTimeout(() => setStatus(null), 8000);
      return () => clearTimeout(timer);
    }
  }, [status]);

  const generateSpectralInsight = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const currentFreqData = HEALING_FREQUENCIES.find(f => f.freq === healingFreq);
      const prompt = `Act as a master of sound alchemy and neuro-acoustics. Analyze this professional meditation arrangement:
        - Sacred Style: ${activeStyle}
        - Mastering Frequency: ${healingFreq}Hz (${currentFreqData?.description})
        - Neural Waveform: ${binaural.targetFrequency}Hz pulses
        Provide a 2-sentence alchemical explanation of how this produced mix will stabilize the listener's nervous system.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      setSpectralInsight(response.text || '');
    } catch (err) {
      setSpectralInsight("Soundstage calibrated. Frequencies are now blending to create a coherent neural field.");
    }
  };

  const startNeuralProcess = async () => {
    if (files.length === 0) {
      setStatus({ type: 'error', msg: 'Neural Source missing. Upload audio or link a public YouTube stream.' });
      return;
    }
    setIsProcessing(true);
    setStatus({ type: 'info', msg: 'Constructing FX Rack & Stem Matrix...' });
    
    await new Promise(r => setTimeout(r, 4500));
    
    try {
      if (!engineRef.current) engineRef.current = new AudioEngine();
      await engineRef.current.start();
      
      const sessionAsset = files[0];
      if (sessionAsset) {
          await engineRef.current.processUserAudio(sessionAsset.url);
      }
      
      generateSpectralInsight();
      setIsPlaying(true);
      setIsProcessing(false);
      setStatus({ type: 'success', msg: `Mastering Chain Active.` });
    } catch (err) {
      setIsProcessing(false);
      setStatus({ type: 'error', msg: 'Engine ignition failure. Check audio source.' });
    }
  };

  const handleYtLink = async () => {
    if (!ytUrl) return;
    setYtStatus('linking');
    setYtProgress(1); 
    setStatus({ type: 'info', msg: 'Verifying Neural Link Status...' });
    
    try {
      if (!engineRef.current) engineRef.current = new AudioEngine();
      
      const { blob, title } = await engineRef.current.downloadYoutubeAsBlob(ytUrl, (pct) => {
        setYtProgress(pct);
      });
      const blobUrl = URL.createObjectURL(blob);
      
      setFiles(prev => [
          ...prev.filter(f => f.sourceType !== 'youtube'),
          { 
            name: title, 
            url: blobUrl, 
            size: blob.size, 
            type: "audio/mp3", 
            sourceType: 'youtube'
          }
      ]);
      setYtStatus('ready');
      setStatus({ type: 'success', msg: 'Conversion complete. Audio synchronized to RAM.' });
    } catch (err: any) {
      console.error("Conversion Error Details:", err);
      setYtStatus('idle');
      setYtProgress(0);
      
      let errorMsg = 'Neural Bridge failed. Try another video link.';
      if (err.message === 'PRIVATE_OR_RESTRICTED') {
          errorMsg = 'ACCESS DENIED: This video is Private or Restricted. Our engine can only process Public videos.';
      } else if (err.message === 'INVALID_YT_URL') {
          errorMsg = 'Invalid YouTube URL structure.';
      } else if (err.message === 'NO_STREAM_LOCATED') {
          errorMsg = 'Extraction nodes are currently blocked by YouTube. Please try again in a few minutes.';
      } else {
          errorMsg = `Bridge Failure: ${err.message || 'Check your connection or video status.'}`;
      }
      
      setStatus({ type: 'error', msg: errorMsg });
    }
  };

  const handleDownload = async () => {
    if (!engineRef.current) return;
    setIsDownloading(true);
    try {
      const blob = await engineRef.current.renderToBlob({ 
        healingFreq, binaural, volumes, fx, stemMode, style: activeStyle 
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `SoulMeditate_Master_${activeStyle.replace(/\s/g, '_')}.wav`;
      a.click();
      setStatus({ type: 'success', msg: 'High-Fi Master Exported.' });
    } catch (err) {
      setStatus({ type: 'error', msg: 'Export failed. Buffer overflow.' });
    } finally { setIsDownloading(false); }
  };

  const togglePlay = () => {
    if (isPlaying) {
      engineRef.current?.stop();
      engineRef.current = null;
      setIsPlaying(false);
      setSpectralInsight('');
    } else startNeuralProcess();
  };

  useEffect(() => {
    if (engineRef.current && isPlaying) {
      engineRef.current.updateSettings({ 
        healingFreq, binaural, volumes, fx, stemMode, style: activeStyle 
      });
    }
  }, [healingFreq, binaural, volumes, fx, stemMode, activeStyle, isPlaying]);

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col items-center bg-[#030208] text-slate-300">
      <div className="max-w-7xl w-full space-y-8">
        <header className="flex flex-col md:flex-row justify-between items-end gap-4 border-b border-slate-900 pb-6">
          <div className="text-left">
            <h1 className="text-5xl font-black tracking-tighter bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-600 bg-clip-text text-transparent uppercase text-glow">Spectral Alchemy</h1>
            <p className="text-slate-600 text-[10px] font-mono uppercase tracking-[0.4em] mt-2">Neural Production Mastering Suite</p>
          </div>
          <div className="flex gap-4">
            <div className="px-4 py-2 bg-slate-950 rounded-xl border border-slate-800 flex flex-col min-w-[160px]">
              <span className="text-[8px] font-mono text-slate-500 uppercase tracking-widest mb-1">Separation Logic</span>
              <select 
                value={stemMode} 
                onChange={e => setStemMode(e.target.value as StemType)}
                className="bg-transparent text-[10px] font-bold text-cyan-400 outline-none cursor-pointer"
              >
                {Object.values(StemType).map(s => <option key={s} value={s} className="bg-slate-950">{s}</option>)}
              </select>
            </div>
          </div>
        </header>

        {status && (
          <div className={`fixed top-4 right-4 z-[110] px-6 py-4 rounded-2xl border backdrop-blur-xl animate-in fade-in slide-in-from-right-8 ${
            status.type === 'error' ? 'bg-red-950/40 border-red-500/30 text-red-400 shadow-[0_0_30px_rgba(239,68,68,0.1)]' :
            status.type === 'success' ? 'bg-green-950/40 border-green-500/30 text-green-400' :
            'bg-cyan-950/40 border-cyan-500/30 text-cyan-400 shadow-[0_0_30px_rgba(34,211,238,0.1)]'
          }`}>
            <div className="text-[8px] font-mono uppercase tracking-widest mb-1 opacity-50">System Link Status</div>
            <div className="text-xs font-bold leading-tight">{status.msg}</div>
          </div>
        )}

        {(isProcessing || isDownloading) && <ProcessingTerminal label={isDownloading ? "Mastering High-Fidelity Envelopes..." : undefined} />}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-8">
            <section className="bg-slate-950/50 rounded-[2rem] p-8 border border-white/5 shadow-2xl">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-1 h-6 bg-cyan-500 rounded-full" />
                <h3 className="text-xs font-mono text-white tracking-[0.2em] uppercase">I. Neural Source Intake</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <FileUploader files={files} setFiles={setFiles} />
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">YouTube Neural Link</h4>
                    {ytStatus === 'ready' && <span className="text-[8px] text-green-500 font-bold animate-pulse uppercase">● Synchronized</span>}
                  </div>
                  <div className="flex gap-2 relative">
                    <input 
                      type="text" value={ytUrl} onChange={e => setYtUrl(e.target.value)}
                      placeholder="Paste Public YouTube Link..."
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs outline-none focus:border-cyan-500 transition-all placeholder:text-slate-700"
                    />
                    <button 
                        onClick={handleYtLink} 
                        disabled={ytStatus === 'linking'}
                        className={`px-4 bg-cyan-500 text-black text-xs font-bold rounded-xl transition-all relative overflow-hidden min-w-[120px] ${ytStatus === 'linking' ? 'opacity-80 cursor-wait shadow-none' : 'hover:bg-cyan-400 shadow-lg shadow-cyan-500/10'}`}
                    >
                      {ytStatus === 'linking' ? (
                        <>
                          <div 
                            className="absolute inset-0 bg-white/30 transition-all duration-300" 
                            style={{ width: `${ytProgress || 5}%` }}
                          />
                          <span className="relative z-10">{ytProgress > 0 ? `${ytProgress}%` : 'SCANNING...'}</span>
                        </>
                      ) : 'CONVERT'}
                    </button>
                  </div>
                  <p className="text-[8px] text-slate-600 font-mono italic leading-relaxed uppercase">Neural Fetcher: Direct binary extraction. Only public, non-restricted videos supported.</p>
                </div>
              </div>
              
              <div className="mt-10">
                <h3 className="text-xs font-mono text-white tracking-[0.2em] uppercase mb-6">II. Atmospheric Synthesis</h3>
                <StyleGrid activeStyle={activeStyle} onSelect={setActiveStyle} customUrl="" onUrlChange={()=>{}} onLocalBackgroundUpload={f => engineRef.current?.loadLocalBackground(f)} />
              </div>
            </section>

            <section className="bg-slate-950/50 rounded-[2rem] p-8 border border-white/5 shadow-2xl">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-1 h-6 bg-purple-500 rounded-full" />
                <h3 className="text-xs font-mono text-white tracking-[0.2em] uppercase">III. Quantum Calibration</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-6">
                  <label className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block mb-4">Healing Fundamental (Hz)</label>
                  <div className="grid grid-cols-2 gap-2">
                    {HEALING_FREQUENCIES.map(f => (
                        <button 
                            key={f.freq}
                            onClick={() => setHealingFreq(f.freq)}
                            className={`p-4 rounded-xl border text-left transition-all ${
                                healingFreq === f.freq 
                                ? 'bg-cyan-500 border-cyan-400 text-slate-950 shadow-lg shadow-cyan-500/20' 
                                : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 text-slate-400'
                            }`}
                        >
                            <div className="text-xs font-black">{f.name}</div>
                            <div className="text-[8px] font-mono opacity-70 uppercase truncate">{f.description}</div>
                        </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-6">
                    <label className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block mb-4">Neural Brainwave Target</label>
                    <div className="space-y-3">
                        {[
                          { id: 'delta', label: 'DELTA', freq: 2, desc: 'Deep Sleep / Repair' },
                          { id: 'theta', label: 'THETA', freq: 6, desc: 'Creative Visualization' },
                          { id: 'alpha', label: 'ALPHA', freq: 10, desc: 'Stress Relief / Flow' },
                          { id: 'beta', label: 'BETA', freq: 20, desc: 'Active Focus' },
                          { id: 'gamma', label: 'GAMMA', freq: 40, desc: 'Peak Cognition' },
                        ].map((wave) => (
                        <button 
                            key={wave.id}
                            onClick={() => setBinaural(p => ({...p, targetFrequency: wave.freq}))}
                            className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all ${
                            binaural.targetFrequency === wave.freq 
                                ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-500/20' 
                                : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 text-slate-400'
                            }`}
                        >
                            <span className="text-[10px] font-black tracking-widest">{wave.label}</span>
                            <span className="text-[9px] font-mono">{wave.freq}Hz — {wave.desc}</span>
                        </button>
                        ))}
                    </div>
                </div>
              </div>
            </section>

            <section className="bg-slate-950/50 rounded-[2rem] p-8 border border-white/5 shadow-2xl">
              <h3 className="text-xs font-mono text-orange-400 mb-8 tracking-[0.2em] uppercase">IV. DSP Mastering Rack</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-slate-400"><span>Reverb Space</span><span>{fx.reverb}%</span></div>
                    <input type="range" min="0" max="100" value={fx.reverb} onChange={e => setFx({...fx, reverb: Number(e.target.value)})} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-indigo-500" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-slate-400"><span>Delay Density</span><span>{fx.delay}%</span></div>
                    <input type="range" min="0" max="100" value={fx.delay} onChange={e => setFx({...fx, delay: Number(e.target.value)})} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-cyan-500" />
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-slate-400"><span>Harmonic Warmth</span><span>{fx.warmth}%</span></div>
                    <input type="range" min="0" max="100" value={fx.warmth} onChange={e => setFx({...fx, warmth: Number(e.target.value)})} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-orange-500" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-slate-400"><span>Delay Time</span><span>{fx.delayTime}ms</span></div>
                    <input type="range" min="50" max="2000" step="50" value={fx.delayTime} onChange={e => setFx({...fx, delayTime: Number(e.target.value)})} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-purple-500" />
                  </div>
                </div>
              </div>
            </section>
          </div>

          <div className="lg:col-span-4 space-y-8">
            <section className="bg-slate-950 rounded-[2.5rem] p-8 border border-white/5 flex flex-col h-full sticky top-8 shadow-2xl">
              <Visualizer engineRef={engineRef} />
              
              {spectralInsight && (
                <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-2xl p-4 mb-6 animate-in fade-in zoom-in">
                    <h4 className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest mb-2">Neural Analysis</h4>
                    <p className="text-[11px] italic text-indigo-100/70 leading-relaxed">"{spectralInsight}"</p>
                </div>
              )}

              <PlayerControls 
                isPlaying={isPlaying} 
                onTogglePlay={togglePlay} 
                onDownload={handleDownload} 
                volumes={volumes} 
                setVolumes={setVolumes} 
                healingFreq={healingFreq} 
                binauralTarget={binaural.targetFrequency} 
              />
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
