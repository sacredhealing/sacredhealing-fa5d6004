
import React from 'react';
import { AudioFile } from '../types';

interface FileUploaderProps {
  files: AudioFile[];
  setFiles: (files: AudioFile[]) => void;
}

const FileUploader: React.FC<FileUploaderProps> = ({ files, setFiles }) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const newFiles = Array.from(e.target.files as FileList).map((f: File) => ({
      name: f.name,
      size: f.size,
      type: f.type,
      url: URL.createObjectURL(f),
      sourceType: 'local' as const
    }));
    setFiles([...files, ...newFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const extractYoutubeId = (url: string): string | null => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  return (
    <div className="space-y-4">
      <div className="relative group">
        <input 
          type="file" 
          multiple 
          accept="audio/*"
          onChange={handleFileChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        <div className="flex flex-col items-center justify-center py-10 border-2 border-dashed border-slate-700 rounded-2xl bg-slate-900/30 group-hover:border-purple-500/50 group-hover:bg-purple-900/5 transition-all">
          <div className="w-12 h-12 bg-purple-600/20 text-purple-400 rounded-full flex items-center justify-center mb-4 text-2xl">
            📤
          </div>
          <p className="text-sm font-semibold text-slate-300">Drop audio files here or click to browse</p>
          <p className="text-[10px] text-slate-500 mt-1">Supports MP3, WAV, M4A, FLAC, AAC, OGG, AIFF</p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Active Intake Sources ({files.length})</p>
          <div className="grid gap-2">
            {files.map((file, i) => {
              const isYoutube = file.sourceType === 'youtube';
              const ytId = isYoutube ? extractYoutubeId(file.url) : null;
              
              return (
                <div key={i} className={`flex items-center justify-between p-3 bg-slate-900 border rounded-xl transition-all ${isYoutube ? 'border-cyan-500/30 shadow-[0_0_15px_rgba(34,211,238,0.1)]' : 'border-slate-800'}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-10 rounded overflow-hidden flex items-center justify-center text-xs ${isYoutube ? 'bg-black' : 'bg-slate-800 text-slate-400'}`}>
                      {isYoutube && ytId ? (
                        <img src={`https://img.youtube.com/vi/${ytId}/default.jpg`} alt="yt-thumb" className="w-full h-full object-cover opacity-60" />
                      ) : (
                        '🎵'
                      )}
                    </div>
                    <div className="overflow-hidden">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-bold text-slate-200 truncate max-w-[140px] md:max-w-none">{file.name}</p>
                        {isYoutube && <span className="text-[7px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-black uppercase tracking-tighter border border-cyan-500/30">Neural</span>}
                      </div>
                      <p className={`text-[10px] font-mono ${isYoutube ? 'text-cyan-500/60 uppercase tracking-tighter' : 'text-slate-500'}`}>
                        {isYoutube ? 'READY TO SPECTRAL-FETCH' : `${(file.size / (1024 * 1024)).toFixed(2)} MB`}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {isYoutube ? (
                       <div className="flex items-center px-2 py-1 rounded bg-slate-950 border border-slate-800 text-[8px] font-bold text-cyan-500 tracking-widest uppercase shadow-inner">
                         LINKED
                       </div>
                    ) : (
                      <button className="p-2 text-slate-400 hover:text-purple-400 transition-colors">✨</button>
                    )}
                    <button 
                      onClick={() => removeFile(i)}
                      className="p-2 text-slate-400 hover:text-red-400 transition-colors"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUploader;
