
import React, { useRef } from 'react';
import { MeditationStyle } from '../types';

interface StyleGridProps {
  activeStyle: MeditationStyle;
  onSelect: (style: MeditationStyle) => void;
  customUrl: string;
  onUrlChange: (url: string) => void;
  onLocalBackgroundUpload: (file: File) => void;
}

const STYLE_DETAILS: Record<MeditationStyle, { icon: string; desc: string; tags: string[] }> = {
  [MeditationStyle.INDIAN_VEDIC]: { icon: "🕉️", desc: "Mantras, tanpura drones, temple bells", tags: ["Tanpura", "Indian Drone"] },
  [MeditationStyle.SHAMANIC]: { icon: "🎭", desc: "Frame drums, rattles, tribal rhythms", tags: ["Drums", "Earth"] },
  [MeditationStyle.MYSTIC]: { icon: "✨", desc: "Etheric pads, choirs, cosmic textures", tags: ["Space", "Deep"] },
  [MeditationStyle.TIBETAN]: { icon: "🔔", desc: "Singing bowls, long horns, overtone chanting", tags: ["Bowls", "Horns"] },
  [MeditationStyle.SUFI]: { icon: "💫", desc: "Whirling rhythms, nay flute, heart devotion", tags: ["Flute", "Rhythm"] },
  [MeditationStyle.ZEN]: { icon: "🎋", desc: "Minimal ambience, breath awareness", tags: ["Bells", "Wind"] },
  [MeditationStyle.NATURE_HEALING]: { icon: "🌿", desc: "Forest, birds, wind, water", tags: ["Nature", "Birds"] },
  [MeditationStyle.OCEAN_WATER]: { icon: "🌊", desc: "Waves, flowing water, deep calming", tags: ["Waves", "Water"] },
  [MeditationStyle.SOUND_BATH]: { icon: "🎵", desc: "Gongs, crystal bowls, harmonic overtones", tags: ["Gongs", "Crystal"] },
  [MeditationStyle.CHAKRA_BALANCING]: { icon: "🌈", desc: "Layered tones for each chakra", tags: ["Tones", "Chakra"] },
  [MeditationStyle.HIGHER_CONSCIOUSNESS]: { icon: "🌌", desc: "Cosmic tones, transcendence", tags: ["Cosmic", "Tones"] },
  [MeditationStyle.RELAXING]: { icon: "😌", desc: "Gentle ambient, stress relief", tags: ["Soft", "Peace"] },
  [MeditationStyle.FOREST]: { icon: "🌲", desc: "Birdsong, rustling leaves, natural calm", tags: ["Wood", "Wind"] },
  [MeditationStyle.BREATH_FOCUS]: { icon: "🫁", desc: "Breath cues, minimal ambience", tags: ["Cues", "Minimal"] },
  [MeditationStyle.KUNDALINI]: { icon: "🐍", desc: "Rising energy, drone + subtle pulses", tags: ["Pulses", "Energy"] },
  [MeditationStyle.CUSTOM_CLOUD]: { icon: "☁️", desc: "Sync sounds from Cloud Storage", tags: ["Cloud", "S3", "Dropbox"] },
  [MeditationStyle.LOCAL_ASSET]: { icon: "📁", desc: "Use your own WAV file as background loop", tags: ["WAV", "MP3", "Local"] }
};

const StyleGrid: React.FC<StyleGridProps> = ({ activeStyle, onSelect, customUrl, onUrlChange, onLocalBackgroundUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLocalFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onLocalBackgroundUpload(file);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {Object.values(MeditationStyle).map((style) => {
          const isActive = activeStyle === style;
          const details = STYLE_DETAILS[style];
          return (
            <button
              key={style}
              onClick={() => onSelect(style)}
              className={`flex flex-col text-left p-3 rounded-xl border transition-all relative overflow-hidden group h-full ${
                isActive 
                  ? 'bg-purple-900/40 border-purple-500 ring-1 ring-purple-500' 
                  : 'bg-slate-900/40 border-slate-700 hover:border-slate-500'
              }`}
            >
              <span className="text-xl mb-1">{details.icon}</span>
              <span className="text-[10px] font-bold text-white mb-1 line-clamp-1">{style}</span>
              <p className="text-[9px] text-slate-400 line-clamp-2 leading-tight mb-2">
                {details.desc}
              </p>
            </button>
          );
        })}
      </div>

      {activeStyle === MeditationStyle.CUSTOM_CLOUD && (
        <div className="p-6 glass rounded-2xl border border-cyan-500/30 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">🔗</div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-widest">Neural Asset Link</h4>
              <p className="text-[9px] text-slate-500 uppercase">Input Direct URL</p>
            </div>
          </div>
          <input 
            type="text"
            placeholder="https://your-cloud.com/background.mp3"
            value={customUrl}
            onChange={(e) => onUrlChange(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-cyan-400 focus:border-cyan-500 transition-all outline-none"
          />
        </div>
      )}

      {activeStyle === MeditationStyle.LOCAL_ASSET && (
        <div className="p-6 glass rounded-2xl border border-purple-500/30 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400">📁</div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-widest">Local Background Asset</h4>
              <p className="text-[9px] text-slate-500 uppercase">Upload your own WAV/MP3 Loop</p>
            </div>
          </div>
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-4 border-2 border-dashed border-slate-800 rounded-xl hover:border-purple-500/50 hover:bg-purple-900/10 transition-all text-xs text-slate-400 font-mono"
          >
            SELECT BACKGROUND WAV FILE
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleLocalFile} 
            className="hidden" 
            accept="audio/*"
          />
          <p className="text-[8px] text-slate-600 mt-2 italic text-center uppercase">This file will be looped automatically under your session.</p>
        </div>
      )}
    </div>
  );
};

export default StyleGrid;
