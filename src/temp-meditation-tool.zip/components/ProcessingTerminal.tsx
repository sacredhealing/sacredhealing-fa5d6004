
import React, { useState, useEffect } from 'react';

interface ProcessingTerminalProps {
  label?: string;
}

const ProcessingTerminal: React.FC<ProcessingTerminalProps> = ({ label }) => {
  const [step, setStep] = useState(0);
  const steps = [
    "Opening Cloud-Sync Workspace...",
    "Decoding Multi-Stem WAV Assets...",
    "Isolating Vocal Transients...",
    "Syncing Alchemical Background Loop...",
    "Calibrating 432Hz Fundamental Matrix...",
    "Applying Neural Entrainment Filters...",
    "Mastering Lossless Output Stream...",
    "Finalizing Alchemical Construct..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setStep(s => (s < steps.length - 1 ? s + 1 : s));
    }, 550);
    return () => clearInterval(interval);
  }, [steps.length]);

  return (
    <div className="fixed inset-0 z-[100] bg-[#030208]/95 backdrop-blur-2xl flex items-center justify-center p-6">
      <div className="max-w-xl w-full bg-slate-900/40 rounded-[2.5rem] border border-cyan-500/20 p-10 shadow-[0_0_150px_rgba(34,211,238,0.15)]">
        <div className="flex items-center gap-6 mb-10">
          <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-slate-800" />
              <div className="absolute inset-0 w-16 h-16 rounded-full border-4 border-cyan-500 border-t-transparent animate-spin" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white tracking-tight">{label || "Neural Alchemy Active"}</h2>
            <p className="text-[9px] font-mono text-cyan-400/50 uppercase tracking-[0.3em] mt-1">High-Fidelity Reconstruction In Progress</p>
          </div>
        </div>

        <div className="space-y-4 font-mono text-[11px]">
          {steps.map((s, i) => {
            const isDone = i < step;
            const isCurrent = i === step;
            return (
                <div key={i} className={`flex gap-4 items-center transition-all duration-300 ${isCurrent ? 'translate-x-2' : ''}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${isDone ? 'bg-cyan-500' : isCurrent ? 'bg-white animate-ping' : 'bg-slate-800'}`} />
                    <span className={isCurrent ? 'text-white font-bold' : isDone ? 'text-slate-400' : 'text-slate-700'}>
                        {isCurrent ? '> ' : ''}{s}
                    </span>
                    {isCurrent && <span className="text-cyan-500 animate-pulse">_</span>}
                </div>
            );
          })}
        </div>

        <div className="mt-12">
            <div className="flex justify-between text-[9px] font-mono text-slate-500 uppercase mb-2">
                <span>Core Sync</span>
                <span>{Math.round(((step + 1) / steps.length) * 100)}%</span>
            </div>
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                <div 
                    className="h-full bg-cyan-500 transition-all duration-700 shadow-[0_0_20px_#22d3ee]" 
                    style={{ width: `${((step + 1) / steps.length) * 100}%` }} 
                />
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProcessingTerminal;
