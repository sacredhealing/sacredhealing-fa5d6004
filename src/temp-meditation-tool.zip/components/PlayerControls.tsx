
import React from 'react';

interface PlayerControlsProps {
  isPlaying: boolean;
  onTogglePlay: () => void;
  onDownload: () => void;
  volumes: { ambient: number; binaural: number; healing: number; user: number };
  setVolumes: (val: any) => void;
  healingFreq: number;
  binauralTarget: number;
}

const PlayerControls: React.FC<PlayerControlsProps> = ({
  isPlaying,
  onTogglePlay,
  onDownload,
  volumes,
  setVolumes,
  healingFreq,
  binauralTarget
}) => {
  const handleVolumeChange = (key: keyof typeof volumes, val: number) => {
    setVolumes((prev: any) => ({ ...prev, [key]: val }));
  };

  return (
    <div className="space-y-6 flex-1 flex flex-col justify-between">
      <div className="space-y-6">
        <div className="text-[10px] font-mono text-slate-500 tracking-[0.3em] uppercase mb-4">Master Level Matrix</div>
        
        <div className="space-y-2 p-4 bg-slate-900/50 rounded-2xl border border-white/5">
            <div className="flex justify-between text-[10px] uppercase font-bold text-cyan-400">
                <span>🎙️ Neural Stem (Session)</span>
                <span>{volumes.user}%</span>
            </div>
            <input 
                type="range" min="0" max="100" value={volumes.user}
                onChange={(e) => handleVolumeChange('user', Number(e.target.value))}
                className="w-full h-2 bg-slate-950 rounded-full appearance-none cursor-pointer accent-cyan-500"
            />
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] uppercase font-bold text-slate-500"><span>Atmospheric Layer</span><span>{volumes.ambient}%</span></div>
            <input type="range" min="0" max="100" value={volumes.ambient} onChange={(e) => handleVolumeChange('ambient', Number(e.target.value))} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-slate-600" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] uppercase font-bold text-slate-500"><span>Binaural Pulse</span><span>{volumes.binaural}%</span></div>
            <input type="range" min="0" max="100" value={volumes.binaural} onChange={(e) => handleVolumeChange('binaural', Number(e.target.value))} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-purple-600" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] uppercase font-bold text-slate-500"><span>Sacred Tone</span><span>{volumes.healing}%</span></div>
            <input type="range" min="0" max="100" value={volumes.healing} onChange={(e) => handleVolumeChange('healing', Number(e.target.value))} className="w-full h-1 bg-slate-900 rounded-full appearance-none accent-pink-600" />
          </div>
        </div>
      </div>

      <div className="pt-8 space-y-3">
        <button 
          onClick={onTogglePlay}
          className={`w-full py-6 rounded-2xl font-black text-xs uppercase tracking-[0.4em] transition-all ${
            isPlaying 
              ? 'bg-red-500/10 text-red-500 border border-red-500/30' 
              : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
          }`}
        >
          {isPlaying ? 'ABORT ENGINE' : 'MASTER AUDIO'}
        </button>
        <button 
          onClick={onDownload} disabled={!isPlaying}
          className={`w-full py-4 rounded-xl border border-slate-700 bg-slate-900/50 text-[10px] font-bold uppercase tracking-widest ${!isPlaying ? 'opacity-20' : 'hover:bg-slate-800'}`}
        >
          DOWNLOAD HI-FI MASTER
        </button>
      </div>
    </div>
  );
};

export default PlayerControls;
