
import React, { useRef, useEffect } from 'react';
import AudioEngine from './AudioEngine';

interface VisualizerProps {
  engineRef: React.RefObject<AudioEngine | null>;
}

const Visualizer: React.FC<VisualizerProps> = ({ engineRef }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    // High density FFT for professional feel
    const dataArray = new Uint8Array(256);

    const draw = () => {
      animationId = requestAnimationFrame(draw);
      if (engineRef.current) {
        engineRef.current.getAnalyzerData(dataArray);
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const barWidth = (canvas.width / dataArray.length) * 1.5;
      let barHeight;
      let x = 0;

      for(let i = 0; i < dataArray.length; i++) {
        barHeight = (dataArray[i] / 255) * canvas.height * 0.8;
        
        // Dynamic alchemical colors based on frequency
        const hue = (i / dataArray.length) * 120 + 180; // Cyan to Purple
        const lightness = 40 + (dataArray[i] / 255) * 30;
        
        ctx.fillStyle = `hsla(${hue}, 80%, ${lightness}%, ${0.3 + (dataArray[i]/255)})`;
        
        // Draw centered bars for aesthetic balance
        const yStart = (canvas.height - barHeight) / 2;
        ctx.fillRect(x, yStart, barWidth, barHeight);
        
        // Subtle glow effect
        if (dataArray[i] > 200) {
            ctx.shadowBlur = 10;
            ctx.shadowColor = `hsla(${hue}, 80%, 50%, 0.5)`;
        } else {
            ctx.shadowBlur = 0;
        }

        x += barWidth + 1;
      }
    };

    draw();
    return () => cancelAnimationFrame(animationId);
  }, [engineRef]);

  return (
    <div className="w-full h-48 bg-black/40 rounded-3xl mb-8 overflow-hidden border border-white/5 relative group">
        <canvas ref={canvasRef} width={800} height={300} className="w-full h-full" />
        <div className="absolute top-4 left-4 flex gap-1 items-end h-3">
            {[1,2,3,4,5].map(i => (
                <div key={i} className="w-1 bg-cyan-500/50 rounded-full animate-pulse" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.1}s` }} />
            ))}
        </div>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <div className="text-[9px] font-mono text-cyan-500/30 uppercase tracking-[0.5em] mb-1">Spectral Core Monitor</div>
            <div className="text-[7px] font-mono text-slate-700 uppercase">Neural Feedback Active</div>
        </div>
        <div className="absolute bottom-4 right-4 text-[8px] font-mono text-slate-700 uppercase group-hover:text-cyan-500/40 transition-colors">
            FFT Resolution: 2048
        </div>
    </div>
  );
};

export default Visualizer;
