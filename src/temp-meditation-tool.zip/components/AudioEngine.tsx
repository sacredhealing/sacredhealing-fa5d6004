
import { MeditationStyle, BinauralConfig, StemType } from '../types';

const STYLE_AUDIO_URLS: Record<MeditationStyle, string> = {
  [MeditationStyle.INDIAN_VEDIC]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  [MeditationStyle.SHAMANIC]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  [MeditationStyle.MYSTIC]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  [MeditationStyle.TIBETAN]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  [MeditationStyle.SUFI]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
  [MeditationStyle.ZEN]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
  [MeditationStyle.NATURE_HEALING]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
  [MeditationStyle.OCEAN_WATER]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
  [MeditationStyle.SOUND_BATH]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
  [MeditationStyle.CHAKRA_BALANCING]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
  [MeditationStyle.HIGHER_CONSCIOUSNESS]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3',
  [MeditationStyle.RELAXING]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3',
  [MeditationStyle.FOREST]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3',
  [MeditationStyle.BREATH_FOCUS]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3',
  [MeditationStyle.KUNDALINI]: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3',
  [MeditationStyle.CUSTOM_CLOUD]: '',
  [MeditationStyle.LOCAL_ASSET]: '',
};

class AudioEngine {
  private ctx: AudioContext | null = null;
  private healingOsc: OscillatorNode[] = [];
  private binauralLeft: OscillatorNode | null = null;
  private binauralRight: OscillatorNode | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private styleGain: GainNode | null = null;
  private binauralGain: GainNode | null = null;
  private healingGain: GainNode | null = null;
  private userAudioGain: GainNode | null = null;
  private analyzer: AnalyserNode | null = null;
  private userBuffer: AudioBuffer | null = null;
  private currentStyleBuffer: AudioBuffer | null = null;
  private styleSource: AudioBufferSourceNode | null = null;
  
  private reverbNode: ConvolverNode | null = null;
  private reverbGain: GainNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;
  private delayGain: GainNode | null = null;
  private warmthNode: WaveShaperNode | null = null;
  private warmthFilter: BiquadFilterNode | null = null;
  
  private vocalFilter: BiquadFilterNode | null = null;
  private instrumentalFilter: BiquadFilterNode | null = null;

  async start() {
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 44100 });
    if (this.ctx.state === 'suspended') await this.ctx.resume();
    
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.setValueAtTime(-30, this.ctx.currentTime);
    this.compressor.knee.setValueAtTime(40, this.ctx.currentTime);
    this.compressor.ratio.setValueAtTime(12, this.ctx.currentTime);
    this.compressor.attack.setValueAtTime(0.001, this.ctx.currentTime);
    this.compressor.release.setValueAtTime(0.2, this.ctx.currentTime);

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0;
    
    this.warmthNode = this.ctx.createWaveShaper();
    this.warmthNode.curve = this.makeSoftSaturationCurve(0.1); 
    this.warmthFilter = this.ctx.createBiquadFilter();
    this.warmthFilter.type = 'lowshelf';
    this.warmthFilter.frequency.value = 200;
    this.warmthFilter.gain.value = 0;

    this.reverbNode = this.ctx.createConvolver();
    this.reverbNode.buffer = this.createImpulseResponse(3.0, 3.0);
    this.reverbGain = this.ctx.createGain();
    this.reverbGain.gain.value = 0;

    this.delayNode = this.ctx.createDelay(2.0);
    this.delayFeedback = this.ctx.createGain();
    this.delayGain = this.ctx.createGain();
    this.delayFeedback.gain.value = 0.25;
    this.delayNode.connect(this.delayFeedback).connect(this.delayNode);

    this.compressor.connect(this.warmthFilter);
    this.warmthFilter.connect(this.warmthNode);
    this.warmthNode.connect(this.masterGain);
    this.warmthNode.connect(this.reverbNode);
    this.reverbNode.connect(this.reverbGain);
    this.reverbGain.connect(this.masterGain);
    this.warmthNode.connect(this.delayNode);
    this.delayNode.connect(this.delayGain);
    this.delayGain.connect(this.masterGain);

    this.masterGain.connect(this.ctx.destination);
    this.masterGain.gain.linearRampToValueAtTime(0.8, this.ctx.currentTime + 3);

    this.styleGain = this.ctx.createGain();
    this.binauralGain = this.ctx.createGain();
    this.healingGain = this.ctx.createGain();
    this.userAudioGain = this.ctx.createGain();

    [this.styleGain, this.binauralGain, this.healingGain, this.userAudioGain].forEach(g => {
        g.gain.value = 0;
        g.connect(this.compressor!);
    });

    this.analyzer = this.ctx.createAnalyser();
    this.analyzer.fftSize = 2048;
    this.masterGain.connect(this.analyzer);
    
    this.vocalFilter = this.ctx.createBiquadFilter();
    this.vocalFilter.type = 'bandpass';
    this.vocalFilter.frequency.value = 1000;
    this.vocalFilter.Q.value = 0.5;

    this.instrumentalFilter = this.ctx.createBiquadFilter();
    this.instrumentalFilter.type = 'notch';
    this.instrumentalFilter.frequency.value = 1000;
    this.instrumentalFilter.Q.value = 0.7;

    this.setupHealingFrequencies();
    this.setupBinauralBeats();
  }

  private stripLeadingSilence(buffer: AudioBuffer): AudioBuffer {
    const threshold = 0.001;
    const channels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    let firstSignificantSample = buffer.length;

    for (let c = 0; c < channels; c++) {
      const data = buffer.getChannelData(c);
      for (let i = 0; i < data.length; i++) {
        if (Math.abs(data[i]) > threshold) {
          if (i < firstSignificantSample) firstSignificantSample = i;
          break;
        }
      }
    }

    if (firstSignificantSample === 0) return buffer;
    const newLength = buffer.length - firstSignificantSample;
    const newBuffer = this.ctx!.createBuffer(channels, newLength, sampleRate);
    for (let c = 0; c < channels; c++) {
      const oldData = buffer.getChannelData(c);
      const newData = newBuffer.getChannelData(c);
      newData.set(oldData.subarray(firstSignificantSample));
    }
    return newBuffer;
  }

  private makeSoftSaturationCurve(amount: number) {
    const k = amount * 5; 
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    for (let i = 0; i < n_samples; ++i) {
      const x = (i * 2) / n_samples - 1;
      curve[i] = (1 + k) * x / (1 + k * Math.abs(x));
    }
    return curve;
  }

  private createImpulseResponse(duration: number, decay: number) {
    const sampleRate = this.ctx!.sampleRate;
    const length = sampleRate * duration;
    const impulse = this.ctx!.createBuffer(2, length, sampleRate);
    for (let i = 0; i < 2; i++) {
      const channelData = impulse.getChannelData(i);
      for (let j = 0; j < length; j++) {
        channelData[j] = (Math.random() * 2 - 1) * Math.pow(1 - j / length, decay) * 0.2;
      }
    }
    return impulse;
  }

  private setupHealingFrequencies() {
    if (!this.ctx || !this.healingGain) return;
    const freqs = [432, 432 * 1.5, 432 * 2];
    freqs.forEach((f, i) => {
      const osc = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, this.ctx!.currentTime);
      g.gain.value = 1 / (i + 1) * 0.05; 
      osc.connect(g).connect(this.healingGain!);
      osc.start();
      this.healingOsc.push(osc);
    });
  }

  private setupBinauralBeats() {
    if (!this.ctx || !this.binauralGain) return;
    const leftPanner = this.ctx.createStereoPanner();
    const rightPanner = this.ctx.createStereoPanner();
    leftPanner.pan.value = -1;
    rightPanner.pan.value = 1;
    this.binauralLeft = this.ctx.createOscillator();
    this.binauralRight = this.ctx.createOscillator();
    this.binauralLeft.type = 'sine';
    this.binauralRight.type = 'sine';
    this.binauralLeft.connect(leftPanner).connect(this.binauralGain);
    this.binauralRight.connect(rightPanner).connect(this.binauralGain);
    this.binauralLeft.start();
    this.binauralRight.start();
  }

  public getAnalyzerData(array: Uint8Array) {
    if (this.analyzer) this.analyzer.getByteFrequencyData(array);
  }

  public extractYoutubeId(url: string): string | null {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  }

  async downloadYoutubeAsBlob(url: string, onProgress?: (pct: number) => void): Promise<{ blob: Blob, title: string }> {
    const videoId = this.extractYoutubeId(url);
    if (!videoId) throw new Error("INVALID_YT_URL");
    
    // PRE-CHECK: Detect private/restricted videos using oembed
    try {
      const oeUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
      const oeRes = await fetch(oeUrl);
      if (!oeRes.ok) {
        if (oeRes.status === 401 || oeRes.status === 403) throw new Error("PRIVATE_OR_RESTRICTED");
        throw new Error("VIDEO_UNREACHABLE");
      }
      const data = await oeRes.json();
      var title = data.title;
    } catch(e: any) { 
      if (e.message === "PRIVATE_OR_RESTRICTED") throw e;
      console.warn("Metadata check bypassed."); 
      title = "YouTube Neural Stream";
    }

    const instances = [
      'inv.tux.rs',
      'invidious.namazso.eu',
      'invidious.drgns.space',
      'inv.vern.cc', 
      'yewtu.be', 
      'invidious.projectsegfau.lt'
    ];
    let streamUrl = '';
    
    for (const inst of instances) {
      try {
        const apiRes = await fetch(`https://${inst}/api/v1/videos/${videoId}`);
        if (!apiRes.ok) continue;
        const data = await apiRes.json();
        // Priority: m4a audio stream
        const format = data.adaptiveFormats.find((f: any) => f.type.includes('audio') && f.container === 'm4a') 
                      || data.adaptiveFormats.find((f: any) => f.type.includes('audio'));
        if (format?.url) {
          streamUrl = format.url;
          break;
        }
      } catch (e) { continue; }
    }

    if (!streamUrl) throw new Error("NO_STREAM_LOCATED");

    const proxies = [
      `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(streamUrl)}`,
      `https://corsproxy.io/?${encodeURIComponent(streamUrl)}`,
      `https://api.allorigins.win/raw?url=${encodeURIComponent(streamUrl)}`
    ];

    let lastError = null;
    for (const pUrl of proxies) {
      try {
        const response = await fetch(pUrl);
        if (!response.ok) continue;

        const contentLength = response.headers.get('content-length');
        const reader = response.body?.getReader();
        if (!reader) continue;

        const total = contentLength ? parseInt(contentLength, 10) : 15000000; 
        let loaded = 0;
        const chunks: Uint8Array[] = [];

        while(true) {
          const {done, value} = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            loaded += value.length;
            if (onProgress) {
              const rawPct = Math.round((loaded / total) * 100);
              onProgress(Math.min(99, Math.max(1, rawPct)));
            }
          }
        }

        if (onProgress) onProgress(100);
        return { blob: new Blob(chunks, { type: 'audio/mpeg' }), title };
      } catch (e) {
        lastError = e;
        continue;
      }
    }

    throw lastError || new Error("PROXY_TUNNEL_FAILURE");
  }

  async processUserAudio(fileUrl: string) {
    if (!this.ctx || !this.userAudioGain) return;
    if (this.ctx.state === 'suspended') await this.ctx.resume();

    try {
      const response = await fetch(fileUrl);
      const arrayBuffer = await response.arrayBuffer();
      const decoded = await this.ctx.decodeAudioData(arrayBuffer);
      
      this.userBuffer = this.stripLeadingSilence(decoded);
      const source = this.ctx.createBufferSource();
      source.buffer = this.userBuffer;
      source.loop = true;
      source.connect(this.userAudioGain);
      this.userAudioGain.gain.setValueAtTime(0, this.ctx.currentTime);
      this.userAudioGain.gain.linearRampToValueAtTime(0.9, this.ctx.currentTime + 3);
      source.start();
    } catch (e) { 
      console.error("Audio Engine Injection Failure:", e); 
      this.triggerHarmonicFailsafe();
    }
  }

  private triggerHarmonicFailsafe() {
    if (!this.ctx || !this.userAudioGain) return;
    const now = this.ctx.currentTime;
    const baseFreq = 108; 
    [1, 1.5, 2, 2.5].forEach((mult, i) => {
        const osc = this.ctx!.createOscillator();
        const g = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(baseFreq * mult, now);
        g.gain.setValueAtTime(0, now);
        g.gain.linearRampToValueAtTime(0.1 / (i + 1), now + 5);
        osc.connect(g).connect(this.userAudioGain!);
        osc.start();
    });
  }

  async setStyleMusic(style: MeditationStyle, urlOrBuffer?: string | AudioBuffer) {
    if (!this.ctx || !this.styleGain) return;
    const now = this.ctx.currentTime;
    if (this.styleSource) {
      try { this.styleSource.stop(); } catch(e) {}
      this.styleSource.disconnect();
    }
    
    if (urlOrBuffer instanceof AudioBuffer) {
        this.currentStyleBuffer = urlOrBuffer;
        this.styleSource = this.ctx.createBufferSource();
        this.styleSource.buffer = this.currentStyleBuffer;
        this.styleSource.loop = true;
        this.styleSource.connect(this.styleGain);
        this.styleSource.start(now);
        return;
    }
    const url = STYLE_AUDIO_URLS[style];
    if (url) {
      try {
        const res = await fetch(url);
        const ab = await res.arrayBuffer();
        this.currentStyleBuffer = await this.ctx.decodeAudioData(ab);
        this.styleSource = this.ctx.createBufferSource();
        this.styleSource.buffer = this.currentStyleBuffer;
        this.styleSource.loop = true;
        this.styleSource.connect(this.styleGain);
        this.styleSource.start(now);
      } catch (e) { console.error("Sacred Atmosphere failure:", e); }
    }
  }

  updateSettings(settings: { 
    healingFreq: number, 
    binaural: BinauralConfig, 
    volumes: { ambient: number, binaural: number, healing: number, user: number },
    fx: { reverb: number, delay: number, delayTime: number, warmth: number },
    stemMode: StemType,
    style: MeditationStyle
  }) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    
    this.healingOsc.forEach(osc => osc.frequency.setTargetAtTime(settings.healingFreq, now, 0.5));
    if (this.binauralLeft && this.binauralRight) {
      this.binauralLeft.frequency.setTargetAtTime(settings.binaural.carrierFrequency, now, 0.1);
      this.binauralRight.frequency.setTargetAtTime(settings.binaural.carrierFrequency + settings.binaural.targetFrequency, now, 0.1);
    }

    this.styleGain?.gain.setTargetAtTime(settings.volumes.ambient / 100 * 0.45, now, 0.5);
    this.binauralGain?.gain.setTargetAtTime(settings.volumes.binaural / 100 * 0.3, now, 0.5);
    this.healingGain?.gain.setTargetAtTime(settings.volumes.healing / 100 * 0.2, now, 0.5);
    this.userAudioGain?.gain.setTargetAtTime(settings.volumes.user / 100 * 0.95, now, 0.5);

    this.reverbGain?.gain.setTargetAtTime(settings.fx.reverb / 100 * 0.4, now, 0.5);
    this.delayGain?.gain.setTargetAtTime(settings.fx.delay / 100 * 0.3, now, 0.5);
    if (this.delayNode) this.delayNode.delayTime.setTargetAtTime(settings.fx.delayTime / 1000, now, 0.5);
    
    if (this.warmthFilter) this.warmthFilter.gain.setTargetAtTime(settings.fx.warmth / 20, now, 0.5);
    if (this.warmthNode) this.warmthNode.curve = this.makeSoftSaturationCurve(settings.fx.warmth / 200);

    if (this.userAudioGain && this.vocalFilter && this.instrumentalFilter && this.compressor) {
        this.userAudioGain.disconnect();
        if (settings.stemMode === StemType.VOCAL_FOCUS) {
            this.userAudioGain.connect(this.vocalFilter).connect(this.compressor);
        } else if (settings.stemMode === StemType.INSTRUMENTAL) {
            this.userAudioGain.connect(this.instrumentalFilter).connect(this.compressor);
        } else {
            this.userAudioGain.connect(this.compressor);
        }
    }
  }

  async renderToBlob(settings: any): Promise<Blob> {
    if (!this.userBuffer) throw new Error("Empty Neural Buffer.");
    const duration = Math.min(this.userBuffer.duration, 600);
    const offlineCtx = new OfflineAudioContext(2, duration * 44100, 44100);
    const offComp = offlineCtx.createDynamicsCompressor();
    const offMaster = offlineCtx.createGain();
    offMaster.gain.setValueAtTime(0, 0);
    offMaster.gain.linearRampToValueAtTime(0.8, 10);
    offMaster.gain.setValueAtTime(0.8, duration - 15);
    offMaster.gain.exponentialRampToValueAtTime(0.001, duration);
    offComp.connect(offMaster).connect(offlineCtx.destination);
    const offUser = offlineCtx.createGain();
    offUser.gain.value = settings.volumes.user / 100 * 0.95;
    const offUSource = offlineCtx.createBufferSource();
    offUSource.buffer = this.userBuffer;
    offUSource.connect(offUser).connect(offComp);
    offUSource.start(0);
    const renderedBuffer = await offlineCtx.startRendering();
    return this.audioBufferToWav(renderedBuffer);
  }

  private audioBufferToWav(buffer: AudioBuffer): Blob {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const length = buffer.length * numChannels * 2 + 44;
    const out = new ArrayBuffer(length);
    const view = new DataView(out);
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) view.setUint8(offset + i, string.charCodeAt(i));
    };
    writeString(0, 'RIFF');
    view.setUint32(4, length - 8, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numChannels * 2, true);
    view.setUint16(32, numChannels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length - 44, true);
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let channel = 0; channel < numChannels; channel++) {
        let sample = buffer.getChannelData(channel)[i];
        sample = Math.max(-1, Math.min(1, sample));
        view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
        offset += 2;
      }
    }
    return new Blob([out], { type: 'audio/wav' });
  }

  stop() {
    this.ctx?.close();
    this.ctx = null;
  }
}

export default AudioEngine;
